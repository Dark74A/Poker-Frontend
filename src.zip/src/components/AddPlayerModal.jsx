import { useState } from "react";
import { Modal } from "./Modal";
import { Field, TextInput } from "./Field";
import { Button } from "./Button";
import { FormError } from "./FormError";

export function AddPlayerModal({
  open,
  onClose,
  onSubmit,
  isSubmitting,
  error,
}) {
  const [displayName, setDisplayName] = useState("");
  const [localError, setLocalError] = useState("");

  function handleClose() {
    setDisplayName("");
    setLocalError("");
    onClose();
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!displayName.trim()) {
      setLocalError("Enter a name for the player.");
      return;
    }
    setLocalError("");
    onSubmit(displayName.trim());
  }

  return (
    <Modal open={open} onClose={handleClose} title="Add player">
      <form onSubmit={handleSubmit} noValidate>
        <FormError>{localError || error}</FormError>
        <Field
          label="Player name"
          hint="Guests can be added with just their name."
        >
          <TextInput
            type="text"
            placeholder="Raj"
            autoFocus
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
          />
        </Field>
        <Button
          type="submit"
          variant="primary"
          loading={isSubmitting}
          style={{ width: "100%" }}
        >
          Add to session
        </Button>
      </form>
    </Modal>
  );
}
